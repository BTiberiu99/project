package gen

type Generator interface {
	Generate(int)
}
