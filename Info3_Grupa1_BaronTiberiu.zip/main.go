package main

import (
	"project/app"
)

func main() {
	app.Start()
}
